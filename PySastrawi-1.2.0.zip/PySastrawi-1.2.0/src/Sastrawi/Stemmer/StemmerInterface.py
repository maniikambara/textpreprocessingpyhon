class StemmerInterface(object):
    """The stemmer interface"""

    def stem(self, text):
        pass


