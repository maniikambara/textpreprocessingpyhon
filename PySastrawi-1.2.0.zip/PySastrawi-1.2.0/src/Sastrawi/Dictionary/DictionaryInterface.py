class DictionaryInterface(object):
    """Interface definition of dictionary"""

    def contains(self, word):
        raise NotImplementedError('you must implement this method manually')